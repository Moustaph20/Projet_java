import java.util.*;

public class Main {
    public static void main(String[] args) {
        // Création de l'objet bibliothèque
        Bibliotheque bibliotheque = new Bibliotheque();

        // Interface utilisateur pour interagir avec le système
        Scanner scanner = new Scanner(System.in);
        int choix=0;

        do {
            System.out.println("\n\nMenu principal :");
            System.out.println("1. Gérer les livres");
            System.out.println("2. Gérer les utilisateurs");
            System.out.println("3. Afficher les statistiques");
            System.out.println("4. Quitter");
            System.out.print("Votre choix : ");

            try {
                choix = scanner.nextInt();
                scanner.nextLine(); // Consommer le retour chariot

                switch (choix) {
                    case 1:
                        gererLivres(bibliotheque, scanner);
                        break;
                    case 2:
                        gererUtilisateurs(bibliotheque, scanner);
                        break;
                    case 3:
                        bibliotheque.afficherStatistiques();
                        break;
                    case 4:
                        System.out.println("Au revoir !");
                        break;
                    default:
                        System.out.println("Choix invalide. Veuillez réessayer.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Erreur : Saisie incorrecte. Veuillez entrer un nombre entier.");
                scanner.nextLine(); // Vider le buffer du scanner
            }
        } while (choix != 4);

        scanner.close();
    }

    // Méthodes pour gérer les livres (implémentées)
    private static void gererLivres(Bibliotheque bibliotheque, Scanner scanner) {
        int choixLivre=0;
        do {
            System.out.println("\n\nGestion des livres :");
            System.out.println("1. Ajouter un livre");
            System.out.println("2. Rechercher un livre");
            System.out.println("3. Supprimer un livre");
            System.out.println("4. Retourner au menu principal");
            System.out.print("Votre choix : ");

            try {
                choixLivre = scanner.nextInt();
                scanner.nextLine(); // Consommer le retour chariot

                switch (choixLivre) {
                    case 1:
                        ajouterLivre(bibliotheque, scanner);
                        break;
                    case 2:
                        rechercherLivre(bibliotheque, scanner);
                        break;
                    case 3:
                        supprimerLivre(bibliotheque, scanner);
                        break;
                    case 4:
                        break;
                    default:
                        System.out.println("Choix invalide. Veuillez réessayer.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Erreur : Saisie incorrecte. Veuillez entrer un nombre entier.");
                scanner.nextLine(); // Vider le buffer du scanner
            }
        } while (choixLivre != 4);
    }

    private static void ajouterLivre(Bibliotheque bibliotheque, Scanner scanner) {
        System.out.print("Saisissez le titre du livre : ");
        String titre = scanner.nextLine();

        System.out.print("Saisissez l'auteur du livre : ");
        String auteur = scanner.nextLine();

        System.out.print("Saisissez l'année de publication du livre : ");
        int anneePublication;
        try {
            anneePublication = scanner.nextInt();
            scanner.nextLine(); // Consommer le retour chariot
        } catch (InputMismatchException e) {
            System.out.println("Erreur : Saisie incorrecte pour l'année. Veuillez entrer un nombre entier.");
            scanner.nextLine(); // Vider le buffer du scanner
            return; // Quitter la méthode si l'année n'est pas un nombre
        }

        System.out.print("Saisissez le ISBN du livre : ");
        String isbn = scanner.nextLine();

        Livre livre = new Livre(titre, auteur, anneePublication, isbn);
        bibliotheque.ajouterLivre(livre);
        System.out.println("Livre " + livre.getTitre() + " ajouté à la bibliothèque.");
    }

    private static void rechercherLivre(Bibliotheque bibliotheque, Scanner scanner) {
        System.out.print("Saisissez le titre du livre (ou laissez vide pour rechercher par auteur et ISBN) : ");
        String titre = scanner.nextLine();

        System.out.print("Saisissez l'auteur du livre (facultatif) : ");
        String auteur = scanner.nextLine();

        System.out.print("Saisissez le ISBN du livre (facultatif) : ");
        String isbn = scanner.nextLine();

        Livre livreRecherche = bibliotheque.rechercherLivre(titre, auteur, isbn);

        if (livreRecherche != null) {
            System.out.println("Livre trouvé : ");
            System.out.println(livreRecherche); // Affiche les informations du livre
        } else {
            System.out.println("Aucun livre trouvé correspondant à votre recherche.");
        }
    }

    private static void supprimerLivre(Bibliotheque bibliotheque, Scanner scanner) {
        System.out.print("Saisissez le titre du livre à supprimer : ");
        String titre = scanner.nextLine();

        Livre livreRecherche = bibliotheque.rechercherLivre(titre, null, null); // Recherche par titre uniquement

        if (livreRecherche != null) {
            bibliotheque.supprimerLivre(livreRecherche);
        } else {
            System.out.println("Livre introuvable.");
        }
    }

    private static void gererUtilisateurs(Bibliotheque bibliotheque, Scanner scanner) {
        int choixUtilisateur=0;
        do {
            System.out.println("\n\nGestion des utilisateurs :");
            System.out.println("1. Créer un utilisateur");
            System.out.println("2. Consulter les informations d'un utilisateur");
            System.out.println("3. Modifier les informations d'un utilisateur");
            System.out.println("4. Supprimer un utilisateur");
            System.out.println("5. Retourner au menu principal");
            System.out.print("Votre choix : ");
    
            try {
                choixUtilisateur = scanner.nextInt();
                scanner.nextLine(); // Consommer le retour chariot
    
                switch (choixUtilisateur) {
                    case 1:
                        creerUtilisateur(bibliotheque, scanner);
                        break;
                    case 2:
                        consulterUtilisateur(bibliotheque, scanner);
                        break;
                    case 3:
                        modifierUtilisateur(bibliotheque, scanner);
                        break;
                    case 4:
                        supprimerUtilisateur(bibliotheque, scanner);
                        break;
                    case 5:
                        break;
                    default:
                        System.out.println("Choix invalide. Veuillez réessayer.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Erreur : Saisie incorrecte. Veuillez entrer un nombre entier.");
                scanner.nextLine(); // Vider le buffer du scanner
            }
        } while (choixUtilisateur != 5);
    }
    
    // Méthodes pour gérer les utilisateurs (à compléter)
    private static void creerUtilisateur(Bibliotheque bibliotheque, Scanner scanner) {
        System.out.print("Saisissez le nom de l'utilisateur : ");
        String nom = scanner.nextLine();
    
        System.out.print("Saisissez le prénom de l'utilisateur : ");
        String prenom = scanner.nextLine();
    
        System.out.print("Saisissez l'adresse email de l'utilisateur : ");
        String email = scanner.nextLine();
    
        System.out.print("Saisissez le numéro de téléphone de l'utilisateur : ");
        int numeroTelephone = scanner.nextInt();
    
        Utilisateur utilisateur = new Utilisateur(nom, prenom, email, numeroTelephone);
        bibliotheque.enregistrerUtilisateur(utilisateur);
        System.out.println("Utilisateur " + utilisateur.getNom() + " " + utilisateur.getPrenom() + " créé avec succès.");
    }
    
    private static void consulterUtilisateur(Bibliotheque bibliotheque, Scanner scanner) {
        System.out.print("Saisissez l'adresse email de l'utilisateur : ");
        String email = scanner.nextLine();
    
        Utilisateur utilisateur = bibliotheque.recupererUtilisateur(email);
    
        if (utilisateur != null) {
            System.out.println("\nInformations de l'utilisateur : ");
            System.out.println("Nom : " + utilisateur.getNom());
            System.out.println("Prénom : " + utilisateur.getPrenom());
            System.out.println("Email : " + utilisateur.getEmail());
            System.out.println("Numéro de téléphone : " + utilisateur.getNumeroTelephone());
            System.out.println("Cotisation à jour : " + (utilisateur.cotisationAJour() ? "Oui" : "Non"));
            System.out.println("Livres empruntés : ");
            for (Livre livreEmprunte : utilisateur.getLivresEmpruntes()) {
                System.out.println("- " + livreEmprunte);
            }
        } else {
            System.out.println("Aucun utilisateur trouvé avec l'adresse email " + email + ".");
        }
    }
    
    private static void modifierUtilisateur(Bibliotheque bibliotheque, Scanner scanner) {
        System.out.print("Saisissez l'adresse email de l'utilisateur à modifier : ");
        String email = scanner.nextLine();
    
        Utilisateur utilisateur = bibliotheque.recupererUtilisateur(email);
    
        if (utilisateur != null) {
            System.out.println("\nInformations actuelles de l'utilisateur : ");
            System.out.println("Nom : " + utilisateur.getNom());
            System.out.println("Prénom : " + utilisateur.getPrenom());
            System.out.println("Email : " + utilisateur.getEmail());
            System.out.println("Numéro de téléphone : " + utilisateur.getNumeroTelephone());

        System.out.println("\nQue souhaitez-vous modifier ?");
        System.out.println("1. Nom");
        System.out.println("2. Prénom");
        System.out.println("3. Email");
        System.out.println("4. Numéro de téléphone");
        System.out.println("5. Annuler");
        System.out.print("Votre choix : ");

        int choixModification;
        try {
            choixModification = scanner.nextInt();
            scanner.nextLine(); // Consommer le retour chariot

            switch (choixModification) {
                case 1:
                    System.out.print("Nouveau nom : ");
                    String nouveauNom = scanner.nextLine();
                    utilisateur.setNom(nouveauNom);
                    System.out.println("Nom de l'utilisateur mis à jour.");
                    break;
                case 2:
                    System.out.print("Nouveau prénom : ");
                    String nouveauPrenom = scanner.nextLine();
                    utilisateur.setPrenom(nouveauPrenom);
                    System.out.println("Prénom de l'utilisateur mis à jour.");
                    break;
                case 3:
                    System.out.print("Nouvelle adresse email : ");
                    String nouvelEmail = scanner.nextLine();
                    utilisateur.setEmail(nouvelEmail);
                    bibliotheque.modifierEmailUtilisateur(utilisateur.getEmail(), nouvelEmail); // Mettre à jour l'email dans la bibliothèque aussi
                    System.out.println("Email de l'utilisateur mis à jour.");
                    break;
                case 4:
                    System.out.print("Nouveau numéro de téléphone : ");
                    int nouveauNumero = scanner.nextInt();
                    utilisateur.setNumeroTelephone(nouveauNumero);
                    System.out.println("Numéro de téléphone de l'utilisateur mis à jour.");
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Choix invalide. Veuillez réessayer.");
            }
        } catch (InputMismatchException e) {
            System.out.println("Erreur : Saisie incorrecte. Veuillez entrer un nombre entier.");
            scanner.nextLine(); // Vider le buffer du scanner
        }
    } else {
        System.out.println("Aucun utilisateur trouvé avec l'adresse email " + email + ".");
    }
}

private static void supprimerUtilisateur(Bibliotheque bibliotheque, Scanner scanner) {
    System.out.print("Saisissez l'adresse email de l'utilisateur à supprimer : ");
    String email = scanner.nextLine();

    Utilisateur utilisateur = bibliotheque.recupererUtilisateur(email);

    if (utilisateur != null) {
        System.out.println("Êtes-vous sûr de vouloir supprimer l'utilisateur " + utilisateur.getNom() + " " + utilisateur.getPrenom() + " ? (oui/non)");
        String confirmation = scanner.nextLine().toLowerCase();

        if (confirmation.equals("oui")) {
            bibliotheque.supprimerUtilisateur(utilisateur);
            System.out.println("Utilisateur supprimé avec succès.");
        } else {
            System.out.println("Suppression annulée.");
        }
    } else {
        System.out.println("Aucun utilisateur trouvé avec l'adresse email " + email + ".");
    }
}

    
}
