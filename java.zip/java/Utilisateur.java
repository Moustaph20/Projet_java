import java.util.ArrayList;

class Utilisateur {
    private String nom;
    private String prenom;
    private String email;
    private int numeroTelephone;
    private int numeroIdentification;
    private ArrayList<Livre> livresEmpruntes;
    private boolean cotisationAJour;

    public Utilisateur(String nom, int numeroIdentification) {
        this.nom = nom;
        this.numeroIdentification = numeroIdentification;
        this.livresEmpruntes = new ArrayList<>();
        this.cotisationAJour = true;
    }
    public Utilisateur(String nom, String prenom, String email,int numeroTelephone) {
        this.nom = nom;
        this.prenom = prenom;
        this.email = email;
        this.numeroTelephone = numeroTelephone;
        this.livresEmpruntes = new ArrayList<>();
        this.cotisationAJour = true;
    }

    // Méthode pour emprunter un livre
    public void emprunterLivre(Livre livre, Bibliotheque bibliotheque) {
        if (bibliotheque.verifierDisponibiliteLivre(livre) && this.cotisationAJour) {
            this.livresEmpruntes.add(livre);
            bibliotheque.supprimerLivre(livre);
            System.out.println("Livre " + livre.getTitre() + " emprunté avec succès par " + this.nom + ".");
        } else {
            System.out.println("Emprunt impossible. Le livre n'est pas disponible ou votre cotisation n'est pas à jour.");
        }
    }
    public void addLivreEmprunte(Livre livre) {
        livresEmpruntes.add(livre);
    }
    public void removeLivreEmprunte(Livre livre) {
        livresEmpruntes.remove(livre);
    }

    // Méthode pour retourner un livre
    public void retournerLivre(Livre livre, Bibliotheque bibliotheque) {
        if (this.livresEmpruntes.contains(livre)) {
            this.livresEmpruntes.remove(livre);
            bibliotheque.ajouterLivre(livre);
            System.out.println("Livre " + livre.getTitre() + " retourné avec succès par " + this.nom + ".");
        } else {
            System.out.println("Erreur : Le livre " + livre.getTitre() + " n'est pas emprunté par cet utilisateur.");
        }
    }

    // Méthode pour afficher les livres empruntés
    public void afficherLivresEmpruntes() {
        if (this.livresEmpruntes.isEmpty()) {
            System.out.println("Cet utilisateur n'a aucun livre emprunté.");
        } else {
            System.out.println("Livres empruntés par " + this.nom + " :");
            for (Livre livre : this.livresEmpruntes) {
                System.out.println("- " + livre);
            }
        }
    }

    // Getters et setters pour les attributs nom, numeroIdentification et cotisationAJour
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

   
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getNumeroTelephone() {
        return numeroTelephone;
    }

    public void setNumeroTelephone(int numeroTelephone) {
        this.numeroTelephone = numeroTelephone;
    }

    public int getNumeroIdentification() {
        return numeroIdentification;
    }

    public void setNumeroIdentification(int numeroIdentification) {
        this.numeroIdentification = numeroIdentification;
    }

    public ArrayList<Livre> getLivresEmpruntes() {
        return livresEmpruntes;
    }

    public void setLivresEmpruntes(ArrayList<Livre> livresEmpruntes) {
        this.livresEmpruntes = livresEmpruntes;
    }
    public boolean cotisationAJour() {
        return cotisationAJour;
    }

    public void setCotisationAJour(boolean cotisationAJour) {
        this.cotisationAJour = cotisationAJour;
    }

}
