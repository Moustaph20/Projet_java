import java.util.*;

public class Bibliotheque {
    private List<Livre> livres;
    private Map<String, Utilisateur> utilisateurs;

    public Bibliotheque() {
        livres = new ArrayList<>();
        utilisateurs = new HashMap<>();
    }

    // Méthodes pour gérer les livres

    public void ajouterLivre(Livre livre) {
        livres.add(livre);
        System.out.println("Livre ajouté avec succès.");
    }

    public Livre rechercherLivre(String titre, String auteur, String isbn) {
        for (Livre livre : livres) {
            if (livre.getTitre().equalsIgnoreCase(titre) || livre.getAuteur().equalsIgnoreCase(auteur) || livre.getISBN().equals(isbn)) {
                return livre;
            }
        }
        return null;
    }
    public boolean verifierDisponibiliteLivre(Livre livre) {
        return livre.getEmprunteur() == null; // Check if the book's `emprunteur` is null (indicating it's available)
    }

    public void supprimerLivre(Livre livre) {
        livres.remove(livre);
        System.out.println("Livre supprimé avec succès.");
    }

    // Méthodes pour gérer les utilisateurs

    public void enregistrerUtilisateur(Utilisateur utilisateur) {
        utilisateurs.put(utilisateur.getEmail(), utilisateur);
        System.out.println("Utilisateur enregistré avec succès.");
    }

    public Utilisateur recupererUtilisateur(String email) {
        return utilisateurs.get(email);
    }

    public void modifierEmailUtilisateur(String ancienEmail, String nouvelEmail) {
        if (utilisateurs.containsKey(ancienEmail)) {
            Utilisateur utilisateur = utilisateurs.get(ancienEmail);
            utilisateur.setEmail(nouvelEmail);
            utilisateurs.put(nouvelEmail, utilisateur); // Mettre à jour la clé dans la map
            utilisateurs.remove(ancienEmail); // Supprimer l'ancienne clé
            System.out.println("Email de l'utilisateur mis à jour avec succès.");
        } else {
            System.out.println("Aucun utilisateur trouvé avec l'adresse email " + ancienEmail + ".");
        }
    }

    public void supprimerUtilisateur(Utilisateur utilisateur) {
        utilisateurs.remove(utilisateur.getEmail());
        System.out.println("Utilisateur supprimé avec succès.");
    }

    public boolean peutEmprunter(Utilisateur utilisateur) {
        return utilisateur.cotisationAJour();
    }

    public void emprunterLivre(Utilisateur utilisateur, Livre livre) {
        if (peutEmprunter(utilisateur)) {
            livre.setEmprunteur(utilisateur);
            utilisateur.addLivreEmprunte(livre);
            System.out.println("Livre " + livre.getTitre() + " emprunté avec succès par " + utilisateur.getNom() + " " + utilisateur.getPrenom() + ".");
        } else {
            System.out.println("L'utilisateur " + utilisateur.getNom() + " " + utilisateur.getPrenom() + " ne peut pas emprunter ce livre car sa cotisation n'est pas à jour.");
        }
    }

    public void rendreLivre(Utilisateur utilisateur, Livre livre) {
        if (livre.getEmprunteur() != null && livre.getEmprunteur().equals(utilisateur)) {
            livre.setEmprunteur(null);
            utilisateur.removeLivreEmprunte(livre);
            System.out.println("Livre " + livre.getTitre() + " rendu avec succès par " + utilisateur.getNom() + " " + utilisateur.getPrenom() + ".");
        } else {
            System.out.println("L'utilisateur " + utilisateur.getNom() + " " + utilisateur.getPrenom() + " n'a pas emprunté ce livre.");
        }
    }

    // Méthodes pour afficher les statistiques

    public void afficherStatistiques() {
        System.out.println("\nStatistiques de la bibliothèque :");
        System.out.println("---------------------------------");

        // Nombre de livres
        System.out.println("Nombre de livres : " + livres.size());

        // Nombre d'utilisateurs
        System.out.println("Nombre d'utilisateurs : " + utilisateurs.size());

        // Nombre d'utilisateurs à jour avec leur cotisation
        int nbUtilisateursCotisationAjour = 0;
        for (Utilisateur utilisateur : utilisateurs.values()) {
            if (utilisateur.cotisationAJour()) {
                nbUtilisateursCotisationAjour++;
            }
        }
        System.out.println("Nombre d'utilisateurs à jour avec leur cotisation : " + nbUtilisateursCotisationAjour);

        // Nombre de livres empruntés (en cours d'emprunt)
        int nbLivresEmpruntes = 0;
        for (Livre livre : livres) {
            if (livre.getEmprunteur() != null) {
                nbLivresEmpruntes++;
            }
        }
        System.out.println("Nombre de livres empruntés : " + nbLivresEmpruntes);

        // Top 3 des utilisateurs ayant emprunté le plus de livres (si applicable)
        if (utilisateurs.size() > 0) {
            Map<Utilisateur, Integer> nbEmpruntsParUtilisateur = new HashMap<>();
            for (Livre livre : livres) {
                if (livre.getEmprunteur() != null) {
                    Utilisateur emprunteur = livre.getEmprunteur();
                    int nbEmprunts = nbEmpruntsParUtilisateur.getOrDefault(emprunteur, 0);
                    nbEmpruntsParUtilisateur.put(emprunteur, nbEmprunts + 1);
                }
            }

            // Tri par ordre décroissant du nombre d'emprunts (à l'aide d'une classe anonyme)
            List<Map.Entry<Utilisateur, Integer>> utilisateursTries = new ArrayList<>(nbEmpruntsParUtilisateur.entrySet());
            utilisateursTries.sort((e1, e2) -> Integer.compare(e2.getValue(), e1.getValue()));

            System.out.println("\nTop 3 des utilisateurs ayant emprunté le plus de livres :");
            int count = 0;
            for (Map.Entry<Utilisateur, Integer> entry : utilisateursTries) {
                if (count < 3) {
                    System.out.println((count + 1) + ". " + entry.getKey().getNom() + " " + entry.getKey().getPrenom() + " (" + entry.getValue() + " emprunt(s))");
                    count++;
                } else {
                    break;
                }
            }
        } else {
            System.out.println("Aucun emprunt de livre n'a encore été effectué.");
        }
    }
}

